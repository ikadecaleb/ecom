-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2021 at 02:31 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `category` varchar(256) NOT NULL,
  `image` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `category`, `image`) VALUES
(20, 'shirt', 'men', 'uploads/1083134130609da079ae73d8.16993437.png'),
(21, 'shoe', 'men', 'uploads/2013189537609da0ec860800.81567968.jpg'),
(22, 'access', 'accessories', 'uploads/459192844609da11213bc45.19951642.jpg'),
(23, 'access', 'women', 'uploads/946230385609da1443d6e37.01328341.jpg'),
(24, 'access', 'accessories', 'uploads/261845076609da1697f4238.55938354.jpg'),
(25, 'access', 'accessories', 'uploads/1716111514609da17d3446d4.98354680.jpg'),
(26, 'home', 'home goods', 'uploads/1017726513609da1b68848f5.93092341.jpg'),
(27, 'home', 'home goods', 'uploads/913825403609da1c9272743.09211353.jpg'),
(28, 'women', 'women', 'uploads/1571669437609da2087d6e40.17106440.jpg'),
(29, 'women', 'women', 'uploads/526830393609da21d2d9425.98335732.jpg'),
(30, 'women', 'women', 'uploads/1234776353609da240a57d80.03265685.jpg'),
(31, 'women', 'women', 'uploads/838683732609da25934ec12.72607133.jpg'),
(32, 'aa', 'accessories', 'uploads/123063577609da27a60e515.11892435.jpg'),
(33, 'aa', 'accessories', 'uploads/106687207609da29696e034.47971611.jpg'),
(34, 'aa', 'home goods', 'uploads/138699745609da3fbbba886.24476050.jpg'),
(35, 'aa', 'home goods', 'uploads/1137228717609da40b6cf201.98013853.jpg'),
(36, 'jhjhjh', 'home goods', 'uploads/42868436660a6fe18b589d8.61195490.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
