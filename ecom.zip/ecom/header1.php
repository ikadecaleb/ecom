<!DOCTYPE html>
<html>
<head>
	<title></title>
  <!--BOOTSRAP links start here-->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
  <!-- bootsrap links stop here-->
	<!--links for styling starts here-->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-theme.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-theme.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.css.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.min.css.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-theme.css.css">
  

  <style>
.zoom {
  
  
  transition: transform .2s; /* Animation */
  
}

.zoom:hover {
  transform: scale(1.2); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}

/* Dropdown Button */
.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd;}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
  
  
  
  
  
	
	<!--links for styling ends here-->
</head>
<body>
	<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="index.php">
<img src="image/logo.png" style="width: 37px; height: 37px;">
    </a>
  </li>
  <li class="nav-item dropdown">

    <a class="nav-link"  href="categories/women.php" >

  WOMEN
  <div class="dropdown-content">
   <span> <a href="categories/women.php">Bracelets</a></span>
   <span><a href="categories/women.php">Earings</a></span>
    <a href="categories/women.php">Necklesses</a>
     <a href="categories/women.php">Sets</a>
      <a href="categories/women.php">Sandales</a>
  
</div>
    </a>
    
  </li>
  <li class="nav-item">
    <a class="nav-link" href="categories/men.php">MEN</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="categories/accessories.php">ACCESSORIES</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="categories/home-goods.php">HOME GOODS</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="categories/all-seasons.php">ALL SEASONS</a>
    <li class="nav-item">
    <a class="nav-link" href="categories/shop.php">SHOP</a>
  </li>
  </li>
</ul>




<!-- links for javascript starts here-->
<script src="js/script.js"></script>
<script src="js/wow.js"></script>
<script src="js/wow.min.js"></script>
<script>
  wow = new WOW(
                      {
                      boxClass:     'wow',      // default
                      animateClass: 'animated', // default
                      offset:       0,          // default
                      mobile:       true,       // default
                      live:         true        // default
                    }
                    )
                    wow.init();
</script>
<!-- links for javascript ends here-->

</body>
</html>