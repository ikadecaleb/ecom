<!DOCTYPE html>
<html>
<head>
	<title>upload</title>
</head>
<body>

	<div>
		
		<img src="image/logo.png" style="width: 37px; height: 37px;">

	</div>
	<h1>upload your file here</h1>

	<form action="upload.php" method="POST" enctype="multipart/form-data">
		<label>name:</label><input type="text" name="name">
		<br>
		<br>
		<label>category</label>
		<select name="category">
			
			<option>men</option>
			<option>women</option>
			<option>accessories</option>
			<option>home goods</option>
			<option>all goods</option>
		</select>
          <br>
          		<br>
		<br>
		<input type="file" name="file">
		<button type="submit" name="submit">submit</button>

	</form>

</body>
</html>