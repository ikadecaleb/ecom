<!DOCTYPE html>
<html>
<head>
	<title></title>
  <!--BOOTSRAP links start here-->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
  <!-- bootsrap links stop here-->
	<!--links for styling starts here-->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	
	<!--links for styling ends here-->
</head>
<body>
	<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="index.php">
      
      <img src="image/logo.png" style="width: 10px; height: 10px;">
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="women.php" >WOMEN</a>
    
  </li>
  <li class="nav-item">
    <a class="nav-link" href="categories/men.php">MEN</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="categories/accessories.php">ACCESSORIES</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="categories/home-goods.php">HOME GOOODS</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="categories/all-seasons.php">ALL SEASONS</a>
    <li class="nav-item">
    <a class="nav-link" href="categories/shop.php">SHOP</a>
  </li>
  </li>
</ul>




<!-- links for javascript starts here-->
<script src="js/script.js"></script>
<script src="js/wow.js"></script>
<script src="js/wow.min.js"></script>
<!-- links for javascript ends here-->

</body>
</html>