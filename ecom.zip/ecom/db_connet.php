<?php
$con=mysqli_connect("localhost","root","","ecom");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }



              function addproduct($name, $category, $image){
              	$con=mysqli_connect("localhost","root","","ecom");

             	# code...
             	$sql = "INSERT INTO product (name,category,image) VALUES ('$name', '$category', '$image')";
				if (mysqli_query($con, $sql)) {
					# code...
					echo "item added successfully";
				}else{
					echo "error:".$sql."<br".mysqli_error($con);
				}

             }

            
  
 ?>
