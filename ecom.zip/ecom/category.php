<?php
//code for home menu

function home($product){
	require("db_connet.php");
	$sql="SELECT * FROM $product  ORDER BY id ASC ";
	if ($result=mysqli_query($con,$sql))
	{
      	//count number of rows in query result
		$rowcount=mysqli_num_rows($result);
      	//if no rows returned show no news alert
		if ($rowcount==0) {
      		# code...
			echo 'No products to fetch';
		}
      	//if there are rows available display all the results
		foreach ($result as $home => $goods) {
      	
				#code...display the results
			
			echo ''.'<a href="categories/'.$goods['category'].'.php" class="align-items-center " style="padding-bottom: 20px;">'.'<div class ="col-xm-6 col-sm-6 col-md-6 col-sm-6 col-lg-6 col-xl-6 view overlay " style="position:relative;">'
			.'<img class="img-thumbnail shadow p-1 mb-5 zoom wow fadeIn" data-wow-duration="1s" data-wow-delay = "1s" style="width:250px;height:150px" src='.$goods['image'].'>'.
			'<a href="categories/'.$goods['category'].'.php" class="btn btn-outline-warning" style="position:absolute; left:0; top:0; ">'.$goods['category'].'</a>'
			.'</div>'.'</a>'.'<br>'.'';
			echo "<br>";
			

		}
	}

	mysqli_close($con);
}


//code for women menu

function women($product){
	require("db_connet.php");
	$sql="SELECT * FROM $product WHERE category='women' ORDER BY id ASC ";
	if ($result=mysqli_query($con,$sql))
	{
      	//count number of rows in query result
		$rowcount=mysqli_num_rows($result);
      	//if no rows returned show no news alert
		if ($rowcount==0) {
      		# code...
			echo 'No products to fetch';
		}
      	//if there are rows available display all the results
		foreach ($result as $women => $womenn) {
      	
				#code...display the results
			
			echo ''.'<div class ="col-xm-6 col-sm-6 col-md-6 col-sm-6 col-lg-6 col-xl-6 my-auto view overlay wow bounceInUp" style="position:relative;">'
			.'<img class="img-thumbnail shadow p-1 mb-5 zoom" style="width:250px;height:150px" src='.'../'.$womenn['image'].'>'.
			'<a href="categories/women.php" class="btn btn-outline-warning" style="position:absolute; left:0; top:0; ">'.$womenn['category'].'</a>'
			.'</div>'.'<br>'.'';
			

		}
	}

	mysqli_close($con);
}

//function for men category
function men($product){
	require("db_connet.php");
	$sql="SELECT * FROM $product WHERE category='men' ORDER BY id ASC";
	if ($result=mysqli_query($con,$sql))
	{
      	//count number of rows in query result
		$rowcount=mysqli_num_rows($result);
      	//if no rows returned show no news alert
		if ($rowcount==0) {
      		# code...
			echo 'No products to fetch';
		}
      	//if there are rows available display all the results
		foreach ($result as $men => $menn) {
      	
				#code...display the results
			
			echo ''.'<div class ="col-xm-6 col-sm-6 col-md-6 col-sm-6 col-lg-6 col-xl-6 my-auto view overlay zoom" style="position:relative;">'
			.'<img class="img-thumbnail shadow p-1 mb-5 zoom" style="width:250px;height:150px" src='.'../'.$menn['image'].'>'.
			'<a href="categories/women.php" class="btn btn-outline-warning" style="position:absolute; left:0; top:0; ">'.$menn['category'].'</a>'
			.'</div>'.'<br>'.'';
			

		}
	}

	mysqli_close($con);
}

//function for accessories category
function accessories($product){
	require("db_connet.php");
	$sql="SELECT * FROM $product WHERE category='accessories' ORDER BY id ASC";
	if ($result=mysqli_query($con,$sql))
	{
      	//count number of rows in query result
		$rowcount=mysqli_num_rows($result);
      	//if no rows returned show no news alert
		if ($rowcount==0) {
      		# code...
			echo 'No products to fetch';
		}
      	//if there are rows available display all the results
		foreach ($result as $accessories => $accessory) {
      	
				#code...display the results
			
			echo ''.'<div class ="col-xm-6 col-sm-6 col-md-6 col-sm-6 col-lg-6 col-xl-6 my-auto view overlay " style="position:relative;">'
			.'<img class="img-thumbnail shadow p-1 mb-5 zoom" style="width:250px;height:150px" src='.'../'.$accessory['image'].'>'.
			'<a href="categories/women.php" class="btn btn-outline-warning" style="position:absolute; left:0; top:0; ">'.$accessory['category'].'</a>'
			.'</div>'.'<br>'.'';
			

		}
	}

	mysqli_close($con);
}

//function for home-goods category
function homegoods($product){
	require("db_connet.php");
	$sql="SELECT * FROM $product WHERE category='home goods' ORDER BY id ASC";
	if ($result=mysqli_query($con,$sql))
	{
      	//count number of rows in query result
		$rowcount=mysqli_num_rows($result);
      	//if no rows returned show no news alert
		if ($rowcount==0) {
      		# code...
			echo 'No products to fetch';
		}
      	//if there are rows available display all the results
		foreach ($result as $goods => $homegoods) {
      	
				#code...display the results
			
			echo ''.'<div class ="col-xm-6 col-sm-6 col-md-6 col-sm-6 col-lg-6 col-xl-6 my-auto view overlay " style="position:relative;">'
			.'<img class="img-thumbnail shadow p-1 mb-5 zoom " style="width:250px;height:150px" src='.'../'.$homegoods['image'].'>'.
			'<a href="categories/women.php" class="btn btn-outline-warning" style="position:absolute; left:0; top:0; ">'.$homegoods['category'].'</a>'
			.'</div>'.'<br>'.'';
			

		}
	}

	mysqli_close($con);
}

//function for all-season category
function allseasons($product){
	require("db_connet.php");
	$sql="SELECT * FROM $product WHERE category='all seasons' ORDER BY id ASC";
	if ($result=mysqli_query($con,$sql))
	{
      	//count number of rows in query result
		$rowcount=mysqli_num_rows($result);
      	//if no rows returned show no news alert
		if ($rowcount==0) {
      		# code...
			echo 'No products to fetch';
		}
      	//if there are rows available display all the results
		foreach ($result as $goods => $allseasons) {
      	
				#code...display the results
			
			echo ''.'<div class ="col-xm-6 col-sm-6 col-md-6 col-sm-6 col-lg-6 col-xl-6 my-auto view overlay" style="position:relative;">'
			.'<img class="img-thumbnail shadow p-1 mb-5 zoom" style="width:250px;height:150px" src='.'../'.$allseasons['image'].'>'.
			'<a href="categories/women.php" class="btn btn-outline-warning" style="position:absolute; left:0; top:0; ">'.$allseasons['category'].'</a>'
			.'</div>'.'<br>'.'';
			

		}
	}

	mysqli_close($con);
}






?>