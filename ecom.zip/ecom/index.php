<?php
include 'header1.php';
include 'category.php';




?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<div class="container align-items-center ">
<br>
<br>
  <div class="row align-items-center">
    <?php
home('product');

    ?>

  </div>
  

</div>

</body>
</html>