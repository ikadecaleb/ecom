<!DOCTYPE html>
<html>
<head>
	<title></title>
  <!--BOOTSRAP links start here-->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
  <!-- bootsrap links stop here-->
	<!--links for styling starts here-->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap/bootstrap-theme.css">
	
	<!--links for styling ends here-->
  <style>
.zoom {
  
  
  transition: transform .2s; /* Animation */
  
}

.zoom:hover {
  transform: scale(1.2); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
</style>
  
</head>
<body>
	<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="../index.php">
      <img src="../image/logo.png" style="width: 37px; height: 37px;">

    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="women.php" >WOMEN</a>
    
  </li>
  <li class="nav-item">
    <a class="nav-link" href="men.php">MEN</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="accessories.php">ACCESSORIES</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="home-goods.php">HOME GOODS</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="all-seasons.php">ALL SEASONS</a>
    <li class="nav-item">
    <a class="nav-link" href="shop.php">SHOP</a>
  </li>
  </li>
</ul>




<!-- links for javascript starts here-->
<script src="js/script.js"></script>
<script src="js/wow.js"></script>
<script src="js/wow.min.js"></script>
<!-- links for javascript ends here-->

</body>
</html>