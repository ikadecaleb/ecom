<?php
include 'header.php';
include '../category.php';



?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<div class="container">
<br>
<br>
  <div class="row" style="margin-bottom: 20px;">
    <?php
accessories('product');

    ?>

  </div>
  

</div>

</body>
</html>