<?php
include 'header.php';
include '../category.php';



?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<div class="container">
<br>
<br>
  <div class="row h-100">
    <?php
allseasons('product');

    ?>

  </div>
  

</div>

</body>
</html>